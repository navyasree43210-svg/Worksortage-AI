# WorkShortage backend

A starter REST API for daily wage job listings, worker applications, map coordinates, and text queries transcribed from voice input. It uses FastAPI and SQLAlchemy. SQLite is the default for a Colab demo; set `DATABASE_URL` to a PostgreSQL connection string when using a hosted database.

## Run in Google Colab

Upload these backend files to a Colab session (or clone/download the project), then run:

```python
%pip install -r requirements.txt
```

Set a secret for the current runtime, start the API in the background, then ask Colab for its proxied URL:

```python
import os, secrets
os.environ["SECRET_KEY"] = secrets.token_urlsafe(48)
!uvicorn main:app --host 0.0.0.0 --port 8000 > /tmp/workshortage.log 2>&1 &
from google.colab.output import eval_js
print(eval_js("google.colab.kernel.proxyPort(8000)"))
```

Open the returned URL with `/docs` appended to reach the interactive API docs. If a separate frontend needs to reach the API, configure a temporary tunnel through a provider you trust; keep its token in Colab Secrets and never commit it. Colab runtime storage and the local SQLite database can disappear when the runtime resets, so use Drive carefully for a class demo or a managed PostgreSQL service for persistent data. Do not treat a Colab session as always-on hosting.

For a local run, copy `.env.example` to `.env`, replace `SECRET_KEY` with a long random value, install dependencies, and start `uvicorn main:app --reload`. The default SQLite database is created automatically at startup. For PostgreSQL, set `DATABASE_URL` to a SQLAlchemy URL such as `postgresql+psycopg://USER:PASSWORD@HOST:5432/DBNAME` before starting the app.

## Demo records

Run `python seed.py` once to add fictional employer/worker accounts and two Bengaluru job posts. Both demo accounts use `DemoPass123!`; do not use these credentials outside a local demo. The seed script is safe to run again and will not duplicate its sample records.

## API overview

All responses and requests use JSON except the OAuth2 login form. Protected routes require `Authorization: Bearer <access_token>`. Register with `POST /auth/register`, then sign in at `POST /auth/token` using form fields `username` (email) and `password`. FastAPI generates full request/response examples at `/docs`.

| Method | Path | Access | Purpose |
| --- | --- | --- | --- |
| GET | `/health` | Public | Health status |
| POST | `/auth/register` | Public | Register a worker or employer |
| POST | `/auth/token` | Public | Sign in and receive an access token |
| POST | `/auth/logout` | Signed-in | Sign-out acknowledgement; client discards token |
| GET, PATCH | `/users/me` | Signed-in | Read or update profile |
| GET | `/jobs` | Public | Search/filter open jobs |
| GET | `/jobs/{job_id}` | Public | Read a job |
| POST | `/jobs` | Employer | Create a job |
| PATCH | `/jobs/{job_id}` | Owning employer | Edit a job |
| POST | `/jobs/{job_id}/close` | Owning employer | Close a job |
| DELETE | `/jobs/{job_id}` | Owning employer | Delete a job |
| POST, DELETE | `/jobs/{job_id}/save` | Worker | Save or unsave a job |
| GET | `/users/me/saved-jobs` | Worker | List saved jobs |
| POST | `/jobs/{job_id}/applications` | Worker | Apply to a job |
| GET | `/users/me/applications` | Worker | List own applications |
| GET | `/jobs/{job_id}/applications` | Owning employer | View applicants |
| PATCH | `/applications/{application_id}` | Owning employer | Update applicant status |
| POST | `/voice/search` | Public | Search from a speech-to-text transcript |

Job search supports `q`, `skill`, `min_pay`, `max_pay`, `work_date` (YYYY-MM-DD), paired `latitude`/`longitude`, `radius_km`, `limit`, and `offset`. Location radius uses a bounding-box prefilter plus Haversine distance calculation. The voice endpoint accepts a transcript, language code, and optional coordinates/radius; speech recognition itself belongs in the frontend. Language is carried through the response but the backend does not translate transcripts.

Example job post:

```json
{
  "title": "Construction helper",
  "description": "Carry materials and help clean the work site.",
  "skills": ["construction", "helper"],
  "pay_amount": 800,
  "pay_type": "daily",
  "work_date": "2026-10-25",
  "schedule": "8:00 AM to 5:00 PM",
  "openings": 3,
  "contact_method": "Call the employer",
  "address": "Indiranagar, Bengaluru",
  "latitude": 12.9784,
  "longitude": 77.6408
}
```

Example voice search:

```json
{
  "transcript": "Find construction work near me",
  "language": "en",
  "latitude": 12.9784,
  "longitude": 77.6408,
  "radius_km": 10
}
```

Example sign-in response:

```json
{
  "access_token": "eyJ...",
  "token_type": "bearer"
}
```

Example voice-search response:

```json
{
  "language": "en",
  "spoken_query": "Find construction work near me",
  "result_count": 1,
  "jobs": [
    {
      "id": 1,
      "title": "Construction helper",
      "pay_amount": 800,
      "pay_type": "daily",
      "address": "Indiranagar, Bengaluru",
      "latitude": 12.9784,
      "longitude": 77.6408,
      "work_date": "2026-10-25"
    }
  ]
}
```

## Database setup and current limits

Tables are created from SQLAlchemy models at application startup. This starter uses `create_all`, suitable for a new demo database; use Alembic migrations before evolving a deployed schema. Set a persistent PostgreSQL `DATABASE_URL` for durable accounts and listings. The API uses signed, expiring bearer tokens; logout is client-side token removal and does not revoke an already-issued token. Add a token denylist or short-lived access tokens with refresh-token rotation if server-side revocation is required. Rate limiting, email/phone verification, production logging, and deployment configuration are also outside this starter.

Never use the fallback development secret in a deployed service. Restrict `CORS_ORIGINS` to the frontend's exact origin(s) before deployment, use HTTPS, and keep `.env` and database credentials private.
