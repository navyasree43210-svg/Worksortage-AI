import math
import os
from contextlib import asynccontextmanager
from datetime import date

from dotenv import load_dotenv
from fastapi import Depends, FastAPI, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy import or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

load_dotenv()

from database import Base, engine, get_db  # noqa: E402
from models import Application, Job, SavedJob, User  # noqa: E402
from schemas import (  # noqa: E402
    ApplicationCreate, ApplicationOut, ApplicationStatusUpdate, JobCreate,
    JobOut, JobUpdate, UserCreate, UserOut, UserUpdate, VoiceJob,
    VoiceSearch, VoiceSearchOut,
)
from security import (  # noqa: E402
    create_access_token, get_current_user, hash_password, require_role,
    verify_password,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    yield


app = FastAPI(title="WorkShortage API", version="1.0.0", lifespan=lifespan)
origins = [o.strip() for o in os.getenv("CORS_ORIGINS", "*").split(",") if o.strip()]
app.add_middleware(
    CORSMiddleware, allow_origins=origins, allow_credentials=False,
    allow_methods=["GET", "POST", "PATCH", "DELETE"], allow_headers=["Authorization", "Content-Type"],
)


def job_dict(job: Job) -> dict:
    return {
        "id": job.id, "employer_id": job.employer_id, "title": job.title,
        "description": job.description,
        "skills": [s for s in job.skills.split(",") if s],
        "pay_amount": job.pay_amount, "pay_type": job.pay_type,
        "work_date": job.work_date, "schedule": job.schedule,
        "openings": job.openings, "contact_method": job.contact_method,
        "address": job.address, "latitude": job.latitude,
        "longitude": job.longitude, "status": job.status,
        "created_at": job.created_at,
    }


def get_job_or_404(db: Session, job_id: int) -> Job:
    job = db.get(Job, job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


def distance_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    earth_radius = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = math.radians(lat2 - lat1), math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * earth_radius * math.asin(math.sqrt(a))


@app.get("/")
def root():
    return {"name": "WorkShortage API", "docs": "/docs", "health": "/health"}


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/auth/register", response_model=UserOut, status_code=201)
def register(payload: UserCreate, db: Session = Depends(get_db)):
    if db.scalar(select(User).where(User.email == payload.email)):
        raise HTTPException(status_code=409, detail="An account with this email already exists")
    user = User(
        name=payload.name.strip(), email=payload.email,
        phone=payload.phone.strip() if payload.phone else None,
        password_hash=hash_password(payload.password), role=payload.role,
        preferred_language=payload.preferred_language,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@app.post("/auth/token")
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == form.username.strip().lower()))
    if user is None or not verify_password(form.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Incorrect email or password", headers={"WWW-Authenticate": "Bearer"})
    return {"access_token": create_access_token(user.id), "token_type": "bearer"}


@app.post("/auth/logout")
def logout(_: User = Depends(get_current_user)):
    # Access tokens are stateless. The client must discard its token on logout.
    return {"message": "Signed out. Remove the access token from the client."}


@app.get("/users/me", response_model=UserOut)
def get_profile(user: User = Depends(get_current_user)):
    return user


@app.patch("/users/me", response_model=UserOut)
def update_profile(payload: UserUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(user, key, value.strip() if isinstance(value, str) else value)
    db.commit()
    db.refresh(user)
    return user


@app.get("/jobs", response_model=list[JobOut])
def search_jobs(
    q: str | None = Query(default=None, max_length=120),
    skill: str | None = Query(default=None, max_length=80),
    min_pay: float | None = Query(default=None, ge=0),
    max_pay: float | None = Query(default=None, ge=0),
    work_date: date | None = None,
    latitude: float | None = Query(default=None, ge=-90, le=90),
    longitude: float | None = Query(default=None, ge=-180, le=180),
    radius_km: float | None = Query(default=None, gt=0, le=500),
    limit: int = Query(default=50, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    db: Session = Depends(get_db),
):
    if (latitude is None) != (longitude is None):
        raise HTTPException(status_code=422, detail="Provide both latitude and longitude")
    statement = select(Job).where(Job.status == "open")
    if q:
        term = f"%{q.strip()}%"
        statement = statement.where(or_(Job.title.ilike(term), Job.description.ilike(term), Job.address.ilike(term)))
    if skill:
        statement = statement.where(Job.skills.ilike(f"%{skill.strip()}%"))
    if min_pay is not None:
        statement = statement.where(Job.pay_amount >= min_pay)
    if max_pay is not None:
        statement = statement.where(Job.pay_amount <= max_pay)
    if work_date:
        statement = statement.where(Job.work_date == work_date)
    statement = statement.order_by(Job.created_at.desc())
    if latitude is not None and radius_km is not None:
        # Bounding box limits rows before the exact Haversine distance check.
        lat_delta = radius_km / 110.574
        lon_delta = radius_km / max(1.0, 111.320 * math.cos(math.radians(latitude)))
        statement = statement.where(
            Job.latitude.between(latitude - lat_delta, latitude + lat_delta),
            Job.longitude.between(longitude - lon_delta, longitude + lon_delta),
        )
        jobs = list(db.scalars(statement.limit(500)))
        jobs = [j for j in jobs if distance_km(latitude, longitude, j.latitude, j.longitude) <= radius_km]
        return [job_dict(j) for j in jobs[offset:offset + limit]]
    return [job_dict(j) for j in db.scalars(statement.offset(offset).limit(limit))]


@app.post("/jobs", response_model=JobOut, status_code=201)
def create_job(payload: JobCreate, db: Session = Depends(get_db), employer: User = Depends(require_role("employer"))):
    values = payload.model_dump()
    values["skills"] = ",".join(sorted({s.strip().lower() for s in values["skills"] if s.strip()}))
    job = Job(**values, employer_id=employer.id)
    db.add(job)
    db.commit()
    db.refresh(job)
    return job_dict(job)


@app.get("/jobs/{job_id}", response_model=JobOut)
def get_job(job_id: int, db: Session = Depends(get_db)):
    return job_dict(get_job_or_404(db, job_id))


@app.patch("/jobs/{job_id}", response_model=JobOut)
def update_job(job_id: int, payload: JobUpdate, db: Session = Depends(get_db), employer: User = Depends(require_role("employer"))):
    job = get_job_or_404(db, job_id)
    if job.employer_id != employer.id:
        raise HTTPException(status_code=403, detail="You can only edit your own job posts")
    for key, value in payload.model_dump(exclude_unset=True).items():
        if key == "skills" and value is not None:
            value = ",".join(sorted({s.strip().lower() for s in value if s.strip()}))
        setattr(job, key, value)
    db.commit()
    db.refresh(job)
    return job_dict(job)


@app.post("/jobs/{job_id}/close", response_model=JobOut)
def close_job(job_id: int, db: Session = Depends(get_db), employer: User = Depends(require_role("employer"))):
    job = get_job_or_404(db, job_id)
    if job.employer_id != employer.id:
        raise HTTPException(status_code=403, detail="You can only close your own job posts")
    job.status = "closed"
    db.commit()
    db.refresh(job)
    return job_dict(job)


@app.delete("/jobs/{job_id}", status_code=204)
def delete_job(job_id: int, db: Session = Depends(get_db), employer: User = Depends(require_role("employer"))):
    job = get_job_or_404(db, job_id)
    if job.employer_id != employer.id:
        raise HTTPException(status_code=403, detail="You can only delete your own job posts")
    db.delete(job)
    db.commit()


@app.post("/jobs/{job_id}/save", status_code=201)
def save_job(job_id: int, db: Session = Depends(get_db), worker: User = Depends(require_role("worker"))):
    job = get_job_or_404(db, job_id)
    if job.status != "open":
        raise HTTPException(status_code=409, detail="This job is closed")
    if db.scalar(select(SavedJob).where(SavedJob.worker_id == worker.id, SavedJob.job_id == job_id)):
        raise HTTPException(status_code=409, detail="Job is already saved")
    db.add(SavedJob(worker_id=worker.id, job_id=job_id))
    db.commit()
    return {"message": "Job saved", "job_id": job_id}


@app.get("/users/me/saved-jobs", response_model=list[JobOut])
def list_saved_jobs(db: Session = Depends(get_db), worker: User = Depends(require_role("worker"))):
    rows = db.scalars(select(SavedJob).where(SavedJob.worker_id == worker.id).order_by(SavedJob.created_at.desc())).all()
    return [job_dict(j) for row in rows if (j := db.get(Job, row.job_id)) is not None]


@app.delete("/jobs/{job_id}/save", status_code=204)
def unsave_job(job_id: int, db: Session = Depends(get_db), worker: User = Depends(require_role("worker"))):
    row = db.scalar(select(SavedJob).where(SavedJob.worker_id == worker.id, SavedJob.job_id == job_id))
    if row is None:
        raise HTTPException(status_code=404, detail="Saved job not found")
    db.delete(row)
    db.commit()


@app.post("/jobs/{job_id}/applications", response_model=ApplicationOut, status_code=201)
def apply_to_job(job_id: int, payload: ApplicationCreate, db: Session = Depends(get_db), worker: User = Depends(require_role("worker"))):
    job = get_job_or_404(db, job_id)
    if job.status != "open":
        raise HTTPException(status_code=409, detail="This job is closed")
    existing = db.scalar(select(Application).where(Application.worker_id == worker.id, Application.job_id == job_id))
    if existing:
        raise HTTPException(status_code=409, detail="You have already applied to this job")
    application = Application(worker_id=worker.id, job_id=job_id, message=payload.message)
    db.add(application)
    db.commit()
    db.refresh(application)
    return application


@app.get("/users/me/applications", response_model=list[ApplicationOut])
def my_applications(db: Session = Depends(get_db), worker: User = Depends(require_role("worker"))):
    return db.scalars(select(Application).where(Application.worker_id == worker.id).order_by(Application.created_at.desc())).all()


@app.get("/jobs/{job_id}/applications", response_model=list[ApplicationOut])
def job_applicants(job_id: int, db: Session = Depends(get_db), employer: User = Depends(require_role("employer"))):
    job = get_job_or_404(db, job_id)
    if job.employer_id != employer.id:
        raise HTTPException(status_code=403, detail="You can only view applicants for your own job posts")
    return db.scalars(select(Application).where(Application.job_id == job_id).order_by(Application.created_at.desc())).all()


@app.patch("/applications/{application_id}", response_model=ApplicationOut)
def update_application(application_id: int, payload: ApplicationStatusUpdate, db: Session = Depends(get_db), employer: User = Depends(require_role("employer"))):
    application = db.get(Application, application_id)
    if application is None:
        raise HTTPException(status_code=404, detail="Application not found")
    if application.job.employer_id != employer.id:
        raise HTTPException(status_code=403, detail="You can only update applications for your own job posts")
    application.status = payload.status
    db.commit()
    db.refresh(application)
    return application


@app.post("/voice/search", response_model=VoiceSearchOut)
def voice_search(payload: VoiceSearch, db: Session = Depends(get_db)):
    """Search using speech-to-text supplied by the client; this endpoint does not record audio."""
    words = [w.strip(".,!?;:") for w in payload.transcript.lower().split()]
    ignored = {"find", "show", "me", "a", "an", "the", "job", "jobs", "work", "near", "in", "for", "please"}
    terms = [w for w in words if len(w) > 2 and w not in ignored][:8]
    statement = select(Job).where(Job.status == "open")
    if terms:
        filters = []
        for term in terms:
            like = f"%{term}%"
            filters.extend([Job.title.ilike(like), Job.description.ilike(like), Job.skills.ilike(like), Job.address.ilike(like)])
        statement = statement.where(or_(*filters))
    if payload.latitude is not None and payload.longitude is not None:
        jobs = list(db.scalars(statement.limit(500)))
        if payload.radius_km:
            jobs = [j for j in jobs if distance_km(payload.latitude, payload.longitude, j.latitude, j.longitude) <= payload.radius_km]
    else:
        jobs = list(db.scalars(statement.order_by(Job.created_at.desc()).limit(100)))
    jobs = jobs[:20]
    return VoiceSearchOut(
        language=payload.language, spoken_query=payload.transcript,
        result_count=len(jobs),
        jobs=[VoiceJob(
            id=j.id, title=j.title, pay_amount=j.pay_amount, pay_type=j.pay_type,
            address=j.address, latitude=j.latitude, longitude=j.longitude, work_date=j.work_date,
        ) for j in jobs],
    )
