from datetime import date, datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


class UserCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    email: str = Field(min_length=3, max_length=255)
    phone: str | None = Field(default=None, max_length=40)
    password: str = Field(min_length=8, max_length=128)
    role: Literal["worker", "employer"]
    preferred_language: str = Field(default="en", min_length=2, max_length=20)

    @field_validator("email")
    @classmethod
    def normalize_email(cls, value: str) -> str:
        value = value.strip().lower()
        if "@" not in value or value.startswith("@") or value.endswith("@"):
            raise ValueError("Enter a valid email address")
        return value


class UserUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=120)
    phone: str | None = Field(default=None, max_length=40)
    preferred_language: str | None = Field(default=None, min_length=2, max_length=20)


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    email: str
    phone: str | None
    role: str
    preferred_language: str
    created_at: datetime


class JobCreate(BaseModel):
    title: str = Field(min_length=2, max_length=160)
    description: str = Field(min_length=5, max_length=5000)
    skills: list[str] = Field(default_factory=list, max_length=30)
    pay_amount: float = Field(gt=0, le=1_000_000)
    pay_type: Literal["hourly", "daily", "fixed"]
    work_date: date | None = None
    schedule: str | None = Field(default=None, max_length=200)
    openings: int = Field(default=1, ge=1, le=1000)
    contact_method: str = Field(min_length=3, max_length=255)
    address: str = Field(min_length=3, max_length=400)
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)


class JobUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=2, max_length=160)
    description: str | None = Field(default=None, min_length=5, max_length=5000)
    skills: list[str] | None = Field(default=None, max_length=30)
    pay_amount: float | None = Field(default=None, gt=0, le=1_000_000)
    pay_type: Literal["hourly", "daily", "fixed"] | None = None
    work_date: date | None = None
    schedule: str | None = Field(default=None, max_length=200)
    openings: int | None = Field(default=None, ge=1, le=1000)
    contact_method: str | None = Field(default=None, min_length=3, max_length=255)
    address: str | None = Field(default=None, min_length=3, max_length=400)
    latitude: float | None = Field(default=None, ge=-90, le=90)
    longitude: float | None = Field(default=None, ge=-180, le=180)


class JobOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    employer_id: int
    title: str
    description: str
    skills: list[str]
    pay_amount: float
    pay_type: str
    work_date: date | None
    schedule: str | None
    openings: int
    contact_method: str
    address: str
    latitude: float
    longitude: float
    status: str
    created_at: datetime


class ApplicationCreate(BaseModel):
    message: str | None = Field(default=None, max_length=2000)


class ApplicationStatusUpdate(BaseModel):
    status: Literal["reviewing", "accepted", "rejected"]


class ApplicationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    worker_id: int
    job_id: int
    message: str | None
    status: str
    created_at: datetime
    updated_at: datetime


class VoiceSearch(BaseModel):
    transcript: str = Field(min_length=1, max_length=500)
    language: str = Field(default="en", min_length=2, max_length=20)
    latitude: float | None = Field(default=None, ge=-90, le=90)
    longitude: float | None = Field(default=None, ge=-180, le=180)
    radius_km: float | None = Field(default=None, gt=0, le=500)


class VoiceJob(BaseModel):
    id: int
    title: str
    pay_amount: float
    pay_type: str
    address: str
    latitude: float
    longitude: float
    work_date: date | None


class VoiceSearchOut(BaseModel):
    language: str
    spoken_query: str
    result_count: int
    jobs: list[VoiceJob]
