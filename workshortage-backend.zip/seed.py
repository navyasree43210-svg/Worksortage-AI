"""Insert fictional local demo accounts and job posts into the configured database."""
from datetime import date

from sqlalchemy import select

from database import Base, SessionLocal, engine
from models import Job, User
from security import hash_password


Base.metadata.create_all(bind=engine)
db = SessionLocal()
try:
    employer = db.scalar(select(User).where(User.email == "employer@example.test"))
    if employer is None:
        employer = User(
            name="Demo Employer", email="employer@example.test", phone="+91 90000 00001",
            password_hash=hash_password("DemoPass123!"), role="employer", preferred_language="en",
        )
        db.add(employer)
        db.flush()
    worker = db.scalar(select(User).where(User.email == "worker@example.test"))
    if worker is None:
        db.add(User(
            name="Demo Worker", email="worker@example.test", phone="+91 90000 00002",
            password_hash=hash_password("DemoPass123!"), role="worker", preferred_language="hi",
        ))
    if not db.scalar(select(Job).where(Job.employer_id == employer.id)):
        db.add_all([
            Job(
                employer_id=employer.id, title="Construction helper", description="Help with carrying materials and site cleanup.",
                skills="construction,helper", pay_amount=800, pay_type="daily", work_date=date.today(),
                schedule="8:00 AM to 5:00 PM", openings=3, contact_method="Call +91 90000 00001",
                address="Indiranagar, Bengaluru", latitude=12.9784, longitude=77.6408, status="open",
            ),
            Job(
                employer_id=employer.id, title="Vegetable market assistant", description="Sort produce and help load deliveries.",
                skills="loading,market", pay_amount=650, pay_type="daily", work_date=date.today(),
                schedule="6:00 AM to noon", openings=2, contact_method="Call +91 90000 00001",
                address="KR Market, Bengaluru", latitude=12.9634, longitude=77.5785, status="open",
            ),
        ])
    db.commit()
    print("Demo data is ready. Both demo accounts use password: DemoPass123!")
finally:
    db.close()
